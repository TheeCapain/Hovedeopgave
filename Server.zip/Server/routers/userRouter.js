import { Router } from "express";
import db from '../database/connection.js';

const userRouter = new Router()




export default userRouter